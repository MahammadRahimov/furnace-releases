"""Is there a newer Furnace? Once a day, one small public file is read: latest.json on the
releases site (GitHub Pages). Nothing about the server is sent: a plain GET, no version, no
counts, no IDs (GitHub sees the IP that asks, like for any download). Nothing is installed.

The result is kept in DATA_DIR/update-check.json. "furnace status" only reads that file, so it
never waits for the internet. Turned off with FURNACE_UPDATE_CHECK=false (UPDATE_CHECK=no in setup).
"""

from __future__ import annotations

import json
import os
import urllib.request
from datetime import datetime, timezone
from typing import Callable

from . import __version__
from .config import Settings

CACHE = "update-check.json"
TIMEOUT = 10
MAX_BYTES = 4096


def parse_version(text: str) -> tuple[int, ...] | None:
    parts = str(text).strip().split(".")
    if not 1 <= len(parts) <= 4 or not all(p.isdigit() and len(p) <= 6 for p in parts):
        return None
    return tuple(int(p) for p in parts)


def newer(latest: str, current: str = __version__) -> bool:
    a, b = parse_version(latest), parse_version(current)
    return a is not None and b is not None and a > b


def _fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "Furnace update check"})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:  # noqa: S310 (https URL from the settings)
        return answer.read(MAX_BYTES + 1)


def check(settings: Settings, fetch: Callable[[str], bytes] = _fetch, now: datetime | None = None) -> dict:
    """Read latest.json and keep the result. Never raises: a problem is kept as "error"."""
    now = now or datetime.now(timezone.utc)
    result = {"checked": now.isoformat(timespec="seconds"), "latest": "", "notes": "", "error": ""}
    try:
        raw = fetch(settings.update_url)
        if len(raw) > MAX_BYTES:
            raise ValueError("the answer is too big")
        data = json.loads(raw.decode("utf-8"))
        latest = str(data.get("version", ""))
        if parse_version(latest) is None:
            raise ValueError(f"no valid version in the answer: {latest[:40]!r}")
        notes = str(data.get("notes", ""))
        result["latest"] = latest
        result["notes"] = notes if notes.startswith("https://") and len(notes) < 300 else ""
    except Exception as exc:  # no internet, a proxy, a changed file: the next day tries again
        result["error"] = (str(exc) or exc.__class__.__name__)[:200]
    path = settings.data_dir / CACHE
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(result) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return result


def read(settings: Settings) -> dict | None:
    try:
        return json.loads((settings.data_dir / CACHE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def how_to_update(docker: bool) -> str:
    if docker:
        return "Update: FURNACE_VERSION in .env, then docker compose pull && docker compose up -d"
    return "Update: sudo furnace upgrade"


def notice(result: dict | None, current: str = __version__, docker: bool = False) -> str:
    """One line when a newer version is out, else ""."""
    if not result or result.get("error") or not newer(result.get("latest", ""), current):
        return ""
    notes = f" Notes: {result['notes']}." if result.get("notes") else ""
    return (f"A new version is available: Furnace {result['latest']} (this server has {current}).{notes} "
            f"{how_to_update(docker)}")


def status_line(settings: Settings, current: str = __version__, docker: bool = False) -> str:
    """For "furnace status": what the last daily check found."""
    if not settings.update_check:
        return "Updates:  the daily check is off (UPDATE_CHECK=no)"
    result = read(settings)
    if result is None:
        return "Updates:  not checked yet (once a day)"
    when = str(result.get("checked", ""))[:16].replace("T", " ")
    if result.get("error"):
        return f"Updates:  the last check did not work ({when} UTC): {result['error']}"
    line = notice(result, current, docker)
    if line:
        return f"Updates:  {line}"
    return f"Updates:  Furnace {current} is the newest version (checked {when} UTC)"


def run(settings: Settings, docker: bool = False, fetch: Callable[[str], bytes] = _fetch) -> str:
    """The daily job. Prints a line only when there is something to say."""
    if not settings.update_check:
        return ""
    result = check(settings, fetch)
    if result["error"]:
        return f"The update check did not work (tried again tomorrow): {result['error']}"
    return notice(result, docker=docker)
